def test():
    print("Museum Security module works!")
